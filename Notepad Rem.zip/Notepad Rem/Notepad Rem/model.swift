//
//  model.swift
//  Notepad Rem
//
//  Created by 2264781 on 10/05/23.
//

import Foundation

import UIKit

struct model{
    
    static var instance = model()
    private let dbContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    private init(){
        
    }
    func addList(titlee: String, descc: String, typee: String, datee: Date, prii: String){
        
        let rem = Datas(context: dbContext)
        
        rem.titlee = titlee
        
        rem.descc = descc
        
        rem.datee = datee
        
        rem.typee = typee
        
        rem.prii = prii
        
        do {
            try dbContext.save()
            print("List added...\(titlee)")
        }
        catch {
            
            print("List NOT added: \(error.localizedDescription)")
            
        }
        
    }
    
    
    func deleteData(rem: Datas) {
        dbContext.delete(rem)
        do {
            try dbContext.save()
        }catch {
            print("Not deleted : \(error.localizedDescription)")
        }
    }
    
    func getAllData() -> [Datas] {
        let remreq = Datas.fetchRequest()
        do {
            let output = try dbContext.fetch(remreq)
            return output
        } catch {
            return []
        }
    }
    
    func getRemByPriority(prii : String) -> [Datas] {
        let remReq = Datas.fetchRequest()
        remReq.predicate = NSPredicate(format: "Priority == %@", prii)
        do {
            let output = try dbContext.fetch(remReq)
            return output
        } catch {
            return []
        }
    }
}


