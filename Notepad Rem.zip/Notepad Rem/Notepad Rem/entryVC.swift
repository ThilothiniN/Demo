//
//  entryVC.swift
//  Notepad Rem
//
//  Created by 2264781 on 10/05/23.
//

import UIKit

class entryVC: UIViewController {
    
    let typeList = ["Personal", "Official"]
    
    @IBOutlet weak var titleT: UITextField!
    
    @IBOutlet weak var descT: UITextField!
    
    @IBOutlet weak var dateP: UIDatePicker!
    
    @IBOutlet weak var typeP: UIPickerView!
    
    var priortype: String?
    
    @IBAction func priority(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0 {
            
        priortype = "Low"
        }
        else if sender.selectedSegmentIndex == 1 {
            
            priortype = "Medium"
            
        }
        else {
            priortype = "High"
            
        }
        
        print("Priority: \(priortype ?? "")")
        
    }
    var selectedType: String? = "Personal"
    override func viewDidLoad() {
        
        super.viewDidLoad()
        print("Home: \(NSHomeDirectory())")
        
        typeP.dataSource = self
        
        typeP.delegate = self
    }
    
    @IBAction func addClick(_ sender: Any) {
        
        let Title = titleT.text ?? ""
        
        let Description = descT.text ?? ""
        
        let Date = dateP.date
        guard !Title.isEmpty && !Description.isEmpty &&  !selectedType!.isEmpty
        else {
            
            return
            
        }
        
        model.instance.addList(titlee: Title, descc: Description, typee: selectedType ?? "Official", datee: Date, prii: priortype ?? ""  )
        
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        view.endEditing(true)
        
    }
    
    
}

extension entryVC: UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return typeList.count
    }
    
}
extension entryVC: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return typeList[row]
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        selectedType = typeList[row]
    }
    
}


