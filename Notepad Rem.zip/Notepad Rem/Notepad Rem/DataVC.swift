//
//  DataVC.swift
//  Notepad Rem
//
//  Created by 2264781 on 10/05/23.
//

import UIKit
import UserNotifications

class DataVC: UIViewController, UNUserNotificationCenterDelegate {

    @IBOutlet weak var remTbl: UITableView!
    var remList: [Datas] = []
    var isAuthorized = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkNotificationPermission()
        
        UNUserNotificationCenter.current().delegate = self
        
        remTbl.dataSource = self
        
        remTbl.delegate = self
    }
    @IBAction func prioritynew(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            remList = model.instance.getAllData()
        case 1:
            remList = remList.filter {
                rem in rem.prii == "Low"
                
            }
        case 2:
            remList = remList.filter {
                rem in rem.prii == "Medium"
            }
        case 3:
            
            remList = remList.filter {
                
                rem in rem.prii == "High"
            }
        default:
            
            break
        }
        
        remTbl.reloadData()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        remList = model.instance.getAllData()
        
        remTbl.reloadData()
        
    }
    func checkNotificationPermission(){
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            switch settings.authorizationStatus {
            case .notDetermined:
                print("Not determined")
                UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, _ in
                    if success {
                        
                        print("User allowed permission")
                        self.isAuthorized = true
                    }
                    else {
                        print("User denied permission")
                        self.isAuthorized = false
                        
                    }
                }
                break
            case .authorized:
                
                print("User already allowed permission")
                
                self.isAuthorized = true
                
            case .denied:
                
                print("User already denied permission")
                self.isAuthorized = false
                
            default:
                break
            }
        }
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        print("App is in background when notificaiton was delivered")
        
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        print("App is in foreground when notificaiton was delivered")
        
    }
    
    @IBAction func notifyClick(_ sender: Any) {
    
        if isAuthorized {
            
            print("Will Notify you ...")
            
            scheduleNotification()
        }
        else {
            showAlert(title: "ERROR", msg: "Permission is not granted for notification \n Go to Settings->NotificationDemo and change the permission")
        }
    }
}
extension DataVC: UITableViewDataSource
{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return remList.count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "remCell", for: indexPath) as! TableViewCell
        
        let rem = remList[indexPath.row]
        
        let remdate = rem.datee
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy  HH:MM"
        let Datetime = formatter.string(from: remdate!)
        cell.titleL.text = rem.titlee
        
        cell.datetimeL.text = Datetime
        
        cell.descriptionL.text = rem.descc
        
        cell.typeL.text = rem.typee
        
        cell.priorityL.text = rem.prii
        
        return cell
        
    }
}



extension DataVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, _ in
            
            print("Delete selected")
            
            let remToDelete = self.remList[indexPath.row]
            
            model.instance.deleteData(rem: remToDelete)
            
            self.remList.remove(at: indexPath.row)
            
            self.remTbl.reloadData()
            
        }
        return UISwipeActionsConfiguration(actions: [deleteAction])
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let rem = remList[indexPath.row]
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "info") as! DetailVC
        vc.selectedRem = rem
        
        show(vc, sender: self)
        remList[indexPath.row] = rem
        remTbl.reloadData()
    }
    
}



