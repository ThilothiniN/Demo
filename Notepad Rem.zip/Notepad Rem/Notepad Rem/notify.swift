//
//  notify.swift
//  Notepad Rem
//
//  Created by 2264781 on 10/05/23.
//

import Foundation
import UIKit
import UserNotifications

extension UIViewController {
    
    func showAlert(title: String, msg: String ){
        
        let alertVC = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default)
        
        alertVC.addAction(okAction)
        
        present(alertVC, animated: true)
        
    }
    
    func scheduleNotification(){
        
        let content = UNMutableNotificationContent()
        
        content.title = "Reminder⏰"
        content.subtitle = ""
        content.body = "10 sec time is over"
        content.sound = .default
        content.badge = 1
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
        
        let request = UNNotificationRequest(identifier: "test1", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
        showAlert(title: "Success", msg: "Notification is scheduled..")
    }
    
}

