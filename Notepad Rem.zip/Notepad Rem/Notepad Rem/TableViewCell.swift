//
//  TableViewCell.swift
//  Notepad Rem
//
//  Created by 2264781 on 10/05/23.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var titleL: UILabel!
    
    @IBOutlet weak var datetimeL: UILabel!
    
    
    @IBOutlet weak var typeL: UILabel!
    
    
    @IBOutlet weak var priorityL: UILabel!
    
    
    
    @IBOutlet weak var descriptionL: UILabel!
    
}
