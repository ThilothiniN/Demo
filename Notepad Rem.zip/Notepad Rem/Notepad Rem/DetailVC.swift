//
//  DetailVC.swift
//  Notepad Rem
//
//  Created by 2264781 on 10/05/23.
//

import UIKit

class DetailVC: UIViewController {
    
    @IBOutlet weak var Dtitle: UILabel!
    
    
    @IBOutlet weak var Ddescrip: UILabel!
    
    @IBOutlet weak var Ddate: UILabel!
    
    @IBOutlet weak var Dtype: UILabel!
    
    @IBOutlet weak var Dprior: UILabel!
    var selectedRem: Datas?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        Dtitle.text = selectedRem?.titlee
        
        let ddate = selectedRem?.datee
        
        let formatter = DateFormatter()
        
        formatter.dateFormat = "dd-MM-yyyy  HH:mm"
        let newDate = formatter.string(from: ddate!)
        Ddate.text = newDate
        Ddescrip.text = selectedRem?.descc
        Dtype.text = selectedRem?.typee
        Dprior.text = selectedRem?.prii
        
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
